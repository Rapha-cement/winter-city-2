# Winterstad 3D voor de (2)3DS
Lowpoly 3D open wereld in C met citro3d: Spidey en Deadpool, stad, missies, eindbaas, muziek in RomFS (zit in de .3dsx).
NOG NIET GETEST op een echt toestel of met de echte bibliotheken: geeft de bouw een fout, stuur die naar mij.

## 1. Bouwen zonder terminal (GitHub)
1. Maak een gratis GitHub-repository en upload ALLE bestanden uit deze zip (inclusief de map `romfs` met de muziek). Vergeet de map `.github` niet.
2. Tabblad Actions > "build-3dsx" > Run workflow.
3. Download na afloop het artifact "winterstad-3dsx" en pak het uit: winterstad.3dsx.

## 2. Op de SD-kaart zetten
- Alleen `/3ds/Winterstad/winterstad.3dsx` (muziek zit erin via RomFS)
- Start via de Homebrew Launcher. Voor de muziek moet `/3ds/dspfirm.cdc` op de SD-kaart staan (heb je meestal al met custom firmware).

## Besturing
Cirkelpad = lopen, L/R = camera, A = springen (ook dubbel), Y = wissel held, B = aanval,
X = web (Spidey, vasthouden) of dash (Deadpool), Spidey klimt tegen een muur met vooruit of A.
SELECT = volgend lied, aanraken van het onderscherm = muziek pauze, START = stoppen.

## .3dsx of .cia?
De .3dsx werkt direct via de Homebrew Launcher. Een .cia (icoontje in het hoofdmenu, installeren met FBI) bouw je er daarna van met makerom en bannertool; dat heb ik nog niet geautomatiseerd.
