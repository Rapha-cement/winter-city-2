
#include <3ds.h>
#include <citro3d.h>
#include <citro2d.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "vshader_shbin.h"

#define TOP_W 400.0f
#define TOP_H 240.0f
#define BOT_W 320.0f
#define BOT_H 240.0f
#define MAX_BUILDINGS 90
#define MAX_MUGS 24
#define MAX_SNOW 12
#define MAX_RINGS 8
#define MAX_TREES 5
#define MAX_STARS 10

#define CLEAR_COLOR 0x182b55FF
#define PI 3.14159265359f

typedef struct { float x,y,z; } V3;
typedef struct { float x,z,w,d,h; } Building;
typedef struct { V3 p; int alive; } Enemy;
typedef struct { V3 p; int active; } Pickup;
typedef struct { V3 p; int active; } Ring;

static DVLB_s* vshader_dvlb;
static shaderProgram_s program;
static int uLoc_projection;
static C3D_Mtx projection;

static C3D_RenderTarget* topTarget;
static C3D_RenderTarget* bottomTarget;
static C2D_TextBuf textBuf;
static C2D_Font font;

static Building buildings[MAX_BUILDINGS];
static int buildingCount = 0;
static Enemy snowmen[MAX_SNOW];
static Pickup mugs[MAX_MUGS];
static Pickup trees[MAX_TREES];
static Ring rings[MAX_RINGS];

static V3 player = {31.0f,0.0f,31.5f};
static V3 vel = {0,0,0};
static float yaw = 0.0f;
static float pitch = 0.22f;
static int hero = 0; /* 0 Spidey, 1 Deadpool */
static int hp = 5;
static int paused = 0;
static int intro = 1;
static int introStep = 0;
static float introTimer = 0;
static int mission = 0;
static int missionStarted = 0;
static int missionBase = 0;
static float missionTimer = 0;
static int packageState = 0;
static int treeCount = 0;
static int ringCount = 0;
static int bossHp = 10;
static V3 boss = {80,110,80};
static float attackTimer = 0;
static float specialTimer = 0;
static float jumpCharge = 0;
static int charging = 0;
static float climbTime = 0;
static float swingTime = 0;
static int attackCount = 0;
static int mugsCollected = 0;
static int snowDefeated = 0;
static int jumpsDone = 0;
static float walked = 0;
static int musicTrack = 0;
static float lastYTap = -10;
static float gameTime = 0;
static int gameWon = 0;

typedef struct {
    u8* data;
    u32 bytes;
    u32 samples;
    float elapsed;
    ndspWaveBuf wave;
    int loaded;
} MusicState;

static MusicState music = {0};
static const char* musicFiles[3] = {
    "romfs:/assets/music/track0.wav",
    "romfs:/assets/music/track1.wav",
    "romfs:/assets/music/track2.wav"
};
static const float musicLengths[3] = {163.0737f, 219.0440f, 129.0797f};

static void musicStop(void){
    ndspChnReset(0);
    if(music.data){
        linearFree(music.data);
        music.data=NULL;
    }
    memset(&music.wave,0,sizeof(music.wave));
    music.bytes=0;
    music.samples=0;
    music.elapsed=0;
    music.loaded=0;
}

static int musicLoad(int track){
    FILE* f;
    long size;
    u8 header[44];
    if(track<0 || track>2) return 0;
    musicStop();
    f=fopen(musicFiles[track],"rb");
    if(!f) return 0;
    if(fread(header,1,sizeof(header),f)!=sizeof(header)){ fclose(f); return 0; }
    if(memcmp(header,"RIFF",4)!=0 || memcmp(header+8,"WAVE",4)!=0 || memcmp(header+12,"fmt ",4)!=0 || memcmp(header+36,"data",4)!=0){
        fclose(f); return 0;
    }
    u16 format=(u16)(header[20] | (header[21]<<8));
    u16 channels=(u16)(header[22] | (header[23]<<8));
    u32 rate=(u32)header[24] | ((u32)header[25]<<8) | ((u32)header[26]<<16) | ((u32)header[27]<<24);
    u16 bits=(u16)(header[34] | (header[35]<<8));
    u32 dataSize=(u32)header[40] | ((u32)header[41]<<8) | ((u32)header[42]<<16) | ((u32)header[43]<<24);
    if(format!=1 || channels!=1 || rate!=11025 || bits!=16 || dataSize==0){ fclose(f); return 0; }
    fseek(f,0,SEEK_END);
    size=ftell(f);
    if(size<44 || dataSize>(u32)(size-44)){ fclose(f); return 0; }
    fseek(f,44,SEEK_SET);
    music.data=(u8*)linearAlloc(dataSize);
    if(!music.data){ fclose(f); return 0; }
    if(fread(music.data,1,dataSize,f)!=dataSize){ fclose(f); musicStop(); return 0; }
    fclose(f);
    music.bytes=dataSize;
    music.samples=dataSize/2;
    music.elapsed=0;
    music.loaded=1;
    memset(&music.wave,0,sizeof(music.wave));
    music.wave.data_vaddr=(u32*)music.data;
    music.wave.nsamples=music.samples;
    music.wave.looping=false;
    DSP_FlushDataCache(music.data,music.bytes);
    ndspChnReset(0);
    ndspChnSetInterp(0,NDSP_INTERP_LINEAR);
    ndspChnSetRate(0,11025.0f);
    ndspChnSetFormat(0,NDSP_FORMAT_MONO_PCM16);
    ndspChnWaveBufAdd(0,&music.wave);
    return 1;
}

static void musicNext(void){
    musicTrack=(musicTrack+1)%3;
    musicLoad(musicTrack);
}

static const char* missionNames[] = {
    "Tutorial: lopen",
    "Tutorial: springen",
    "Tutorial: klimmen",
    "Tutorial: zwaaien",
    "Tutorial: Deadpool",
    "Verzamel 10 chocomelk",
    "Versla 5 sneeuwmannen",
    "Bezorg het pakket",
    "Red de kerstbomen",
    "Race door de 8 ringen",
    "Klim naar het dak",
    "Versla Koning Frostbite"
};

static const char* introText[] = {
    "Verteller: Een klein huisje achter het tankstation. Spidey en Deadpool slapen nog...",
    "Spidey: Mmm... Kerstochtend. Waarom is het buiten zo stil?",
    "Deadpool: Mijn chocomelk! Wie heeft mijn chocomelk gepikt?!",
    "Spidey: Kom, we gaan door het raam. De deur klemt toch altijd.",
    "Deadpool: Ja ja, we zijn arm, maar het is wel ons huisje.",
    "Spidey: De kerstbomen... ze zijn allemaal weg!",
    "Deadpool: En de grote toren met al die versiering is ook verdwenen!",
    "Verteller: Kerstavond in Winterstad. Overal schitteren de lichtjes, maar boven de stad hangt een donkere schaduw.",
    "Spidey: Niet zolang wij er zijn.",
    "Deadpool: Ik kwam eigenlijk voor de chocomelk. De rest is bonus.",
    "Spidey: Op pad! Zoek eerst wat chocomelk."
};

static u32 rgb(u8 r,u8 g,u8 b) { return C2D_Color32(r,g,b,255); }
static V3 v3(float x,float y,float z){ V3 v={x,y,z}; return v; }
static float dist2(float ax,float az,float bx,float bz){float x=ax-bx,z=az-bz;return sqrtf(x*x+z*z);}
static float clampf(float a,float b,float x){return x<a?a:(x>b?b:x);}

static void initShader(void) {
    vshader_dvlb = DVLB_ParseFile((u32*)vshader_shbin, vshader_shbin_size);
    shaderProgramInit(&program);
    shaderProgramSetVsh(&program, &vshader_dvlb->DVLE[0]);
    C3D_BindProgram(&program);
    uLoc_projection = shaderInstanceGetUniformLocation(program.vertexShader, "projection");
    C3D_AttrInfo* attr = C3D_GetAttrInfo();
    AttrInfo_Init(attr);
    AttrInfo_AddLoader(attr, 0, GPU_FLOAT, 3);
    AttrInfo_AddLoader(attr, 1, GPU_FLOAT, 4);
    C3D_TexEnv* env = C3D_GetTexEnv(0);
    C3D_TexEnvInit(env);
    C3D_TexEnvSrc(env, C3D_Both, GPU_PRIMARY_COLOR, 0, 0);
    C3D_TexEnvFunc(env, C3D_Both, GPU_REPLACE);
    C3D_DepthTest(true, GPU_GEQUAL, GPU_WRITE_ALL);
    C3D_DepthMap(true, -1.0f, 0.0f);
    C3D_CullFace(GPU_CULL_NONE);
}

static void addBuilding(float x,float z,float w,float d,float h){
    if(buildingCount>=MAX_BUILDINGS) return;
    buildings[buildingCount++] = (Building){x,z,w,d,h};
}

static void buildCity(void){
    buildingCount=0;
    for(int i=-4;i<=4;i++) for(int j=-4;j<=4;j++){
        if((i==0&&j==0) || (i==1&&j==1)) continue;
        float x=i*26.0f+4.0f, z=j*26.0f+4.0f;
        float h=10.0f+((i*i+j*j*3)%6)*5.0f;
        if(i==3&&j==3){x=80;z=80;h=110;}
        addBuilding(x,z, (i==3&&j==3)?14:10+(i+j&1)*3, (i==3&&j==3)?14:10, h);
    }
    for(int i=0;i<MAX_SNOW;i++){
        snowmen[i].p=v3(-70+(i%4)*35,0,-70+(i/4)*35);
        snowmen[i].alive=1;
    }
    for(int i=0;i<MAX_MUGS;i++){
        mugs[i].p=v3(-90+(i%6)*32,1.0f,-70+(i/6)*32);
        mugs[i].active=1;
    }
    for(int i=0;i<MAX_TREES;i++){
        trees[i].p=v3(13+(i*2)*26,0,70+(i%2)*35);
        trees[i].active=1;
    }
    for(int i=0;i<MAX_RINGS;i++){
        float a=(float)i*0.8f;
        rings[i].p=v3(13+26*((i%4)-1),7+(i%3)*5,35+i*24);
        rings[i].active=1;
    }
}

static int nearBuilding(float x,float z,float* nx,float* nz,float* top){
    for(int i=0;i<buildingCount;i++){
        Building*b=&buildings[i];
        float hx=b->w/2.0f+0.65f,hz=b->d/2.0f+0.65f;
        float ax=x-b->x,az=z-b->z;
        if(fabsf(ax)<hx && fabsf(az)<hz){
            if(nx) *nx=(fabsf(ax)>fabsf(az))?(ax>0?1:-1):0;
            if(nz) *nz=(fabsf(az)>=fabsf(ax))?(az>0?1:-1):0;
            if(top) *top=b->h;
            return 1;
        }
    }
    return 0;
}

static void drawCube(const C3D_Mtx* view,float x,float y,float z,float sx,float sy,float sz,u32 color){
    float r=((color>>24)&255)/255.0f, g=((color>>16)&255)/255.0f, b=((color>>8)&255)/255.0f, a=(color&255)/255.0f;
    C3D_Mtx model,mv;
    Mtx_Identity(&model);
    Mtx_Scale(&model,sx,sy,sz);
    Mtx_Translate(&model,x,y,z,true);
    Mtx_Multiply(&mv,view,&model);
    static const float vv[8][3]={
        {-1,-1,-1},{1,-1,-1},{1,1,-1},{-1,1,-1},
        {-1,-1,1},{1,-1,1},{1,1,1},{-1,1,1}
    };
    static const int tri[36]={0,1,2,0,2,3,4,6,5,4,7,6,0,4,5,0,5,1,2,6,7,2,7,3,1,5,6,1,6,2,0,3,7,0,7,4};
    C3D_FVUnifMtx4x4(GPU_VERTEX_SHADER,uLoc_projection,&projection);
    C3D_ImmDrawBegin(GPU_TRIANGLES);
    for(int i=0;i<36;i++){
        int q=tri[i];
        C3D_FVec p=Mtx_MultiplyFVecH(&mv,FVec3_New(vv[q][0],vv[q][1],vv[q][2]));
        C3D_ImmSendAttrib(p.x,p.y,p.z,1.0f);
        C3D_ImmSendAttrib(r,g,b,a);
    }
    C3D_ImmDrawEnd();
}

static void drawPlayer(const C3D_Mtx* view){
    u32 red=rgb(198,20,28), blue=rgb(29,79,184), black=rgb(24,24,24), white=rgb(245,245,245);
    float x=player.x,z=player.z,y=player.y;
    u32 body=hero?red:red;
    drawCube(view,x,y+0.65f,z,.3f,.6f,.3f,hero?black:red);
    drawCube(view,x,y+1.65f,z,.6f,.6f,.3f,hero?red:blue);
    drawCube(view,x,y+2.35f,z,.4f,.4f,.4f,hero?black:red);
    drawCube(view,x-.48f,y+1.55f,z,.3f,.6f,.3f,hero?black:red);
    drawCube(view,x+.48f,y+1.55f,z,.3f,.6f,.3f,hero?black:red);
    drawCube(view,x-.22f,y+.05f,z,.3f,.55f,.3f,hero?black:red);
    drawCube(view,x+.22f,y+.05f,z,.3f,.55f,.3f,hero?black:red);
    if(hero==0 && attackTimer>0){
        float fx=sinf(yaw),fz=cosf(yaw);
        for(int i=1;i<5;i++) drawCube(view,x+fx*i*1.2f,y+1.5f,z+fz*i*1.2f,.04f,.04f,.5f,white);
    }
    if(hero==1 && attackTimer>0){
        float fx=sinf(yaw),fz=cosf(yaw);
        drawCube(view,x+fx*1.5f,y+1.3f,z+fz*1.5f,.08f,.08f,1.0f,white);
        drawCube(view,x+fx*1.1f,y+1.3f,z+fz*1.1f,.14f,.08f,.18f,rgb(212,160,23));
    }
}

static void drawWorld(const C3D_Mtx* view){
    drawCube(view,0,-0.6f,0,140,0.6f,140,rgb(220,232,248));
    for(int i=0;i<buildingCount;i++){
        Building*b=&buildings[i];
        u32 c=(i%4==0)?rgb(45,76,120):(i%4==1)?rgb(90,52,68):(i%4==2)?rgb(40,85,90):rgb(75,72,92);
        drawCube(view,b->x,b->h/2,b->z,b->w/2,b->h/2,b->d/2,c);
        if(b->h>25){
            drawCube(view,b->x,b->h+.8f,b->z,b->w*.33f,.8f,b->d*.33f,rgb(235,240,250));
        }
    }
    for(int i=0;i<MAX_SNOW;i++) if(snowmen[i].alive){
        V3 p=snowmen[i].p;
        drawCube(view,p.x,p.y+.5f,p.z,.45f,.5f,.45f,rgb(238,242,250));
        drawCube(view,p.x,p.y+1.25f,p.z,.32f,.32f,.32f,rgb(248,250,255));
        drawCube(view,p.x-.12f,p.y+1.28f,p.z-.30f,.05f,.05f,.05f,rgb(30,30,30));
        drawCube(view,p.x+.12f,p.y+1.28f,p.z-.30f,.05f,.05f,.05f,rgb(30,30,30));
    }
    for(int i=0;i<MAX_MUGS;i++) if(mugs[i].active)
        drawCube(view,mugs[i].p.x,mugs[i].p.y,mugs[i].p.z,.18f,.3f,.18f,rgb(212,160,23));
    for(int i=0;i<MAX_TREES;i++) if(trees[i].active){
        V3 p=trees[i].p;
        drawCube(view,p.x,p.y+1.2f,p.z,.8f,1.2f,.8f,rgb(35,120,60));
        drawCube(view,p.x,p.y+.25f,p.z,.18f,.25f,.18f,rgb(90,55,30));
    }
    if(mission==11){
        drawCube(view,boss.x,boss.y+3,boss.z,2.4f,3,2.4f,rgb(210,230,245));
        drawCube(view,boss.x,boss.y+6,boss.z,1.7f,1.7f,1.7f,rgb(235,245,255));
    }
    for(int i=0;i<MAX_RINGS;i++) if(rings[i].active){
        V3 p=rings[i].p;
        drawCube(view,p.x,p.y,p.z,.18f,2.4f,2.4f,rgb(77,210,255));
    }
    if(specialTimer>0 && hero==0){
        float fx=sinf(yaw),fz=cosf(yaw);
        for(int i=1;i<8;i++) drawCube(view,player.x+fx*i*2.0f,player.y+2.0f,player.z+fz*i*2.0f,.035f,.035f,.035f,rgb(255,255,255));
    }
}

static void parseText(C2D_Text* t,const char* s,u32 color){
    C2D_TextBufClear(textBuf);
    C2D_TextFontParse(t,font,textBuf,s);
    C2D_TextOptimize(t);
    (void)color;
}

static void drawText(const char* s,float x,float y,float scale,u32 color){
    C2D_Text t;
    C2D_TextFontParse(&t,font,textBuf,s);
    C2D_DrawText(&t,C2D_WithColor,x,y,0.0f,scale,scale,color);
}

static void drawBottom(void){
    C2D_SceneBegin(bottomTarget);
    C2D_DrawRectangle(0,0,0,BOT_W,BOT_H,rgb(10,18,36),rgb(10,18,36),rgb(10,18,36),rgb(10,18,36));
    C2D_DrawRectangle(8,8,0,304,58,rgb(24,42,76),rgb(24,42,76),rgb(24,42,76),rgb(24,42,76));
    char buf[128];
    snprintf(buf,sizeof(buf),"%s  |  HP %d/5",hero?"DEADPOOL":"SPIDEY",hp);
    drawText(buf,18,15,0.55f,rgb(245,248,255));
    snprintf(buf,sizeof(buf),"MISSIE %d/12  %s",mission+1,missionNames[mission]);
    drawText(buf,18,37,0.42f,rgb(255,214,92));

    C2D_DrawRectangle(8,74,0,150,150,rgb(18,30,54),rgb(18,30,54),rgb(18,30,54),rgb(18,30,54));
    /* clean minimap */
    for(int i=-4;i<=4;i++){
        float x=83+i*16;
        C2D_DrawLine(x,82,0,x,216,0,rgb(65,84,115),1.0f);
        C2D_DrawLine(16,149+i*16,0,150,149+i*16,0,rgb(65,84,115),1.0f);
    }
    for(int i=0;i<buildingCount;i++){
        float dx=(buildings[i].x-player.x)*.55f, dz=(buildings[i].z-player.z)*.55f;
        if(fabsf(dx)<70&&fabsf(dz)<70)
            C2D_DrawRectangle(83+dx,149+dz,0,5,5,rgb(100,115,145),rgb(100,115,145),rgb(100,115,145),rgb(100,115,145));
    }
    C2D_DrawCircleSolid(83,149,0,4,rgb(255,90,106));
    if(mission==11) C2D_DrawCircleSolid(83+(boss.x-player.x)*.55f,149+(boss.z-player.z)*.55f,0,4,rgb(255,214,92));

    C2D_DrawRectangle(170,74,0,142,58,rgb(24,42,76),rgb(24,42,76),rgb(24,42,76),rgb(24,42,76));
    snprintf(buf,sizeof(buf),"❤ %d     CHOCO %d/10",hp,mugsCollected);
    drawText(buf,180,83,0.46f,rgb(255,255,255));
    snprintf(buf,sizeof(buf),"☃ %d/5   ★ %d/8",snowDefeated,ringCount);
    drawText(buf,180,105,0.46f,rgb(255,255,255));

    C2D_DrawRectangle(170,142,0,142,74,rgb(24,42,76),rgb(24,42,76),rgb(24,42,76),rgb(24,42,76));
    const char* controls=paused?"GAME PAUSED":"A attack   B jump   R special";
    drawText(controls,180,151,0.42f,rgb(220,232,248));
    snprintf(buf,sizeof(buf),"Y muziek  |  track %d/3",musicTrack+1);
    drawText(buf,180,174,0.42f,rgb(180,205,235));

    /* actual touch pause/play control */
    u32 button=paused?rgb(47,150,93):rgb(190,48,62);
    C2D_DrawCircleSolid(280,201,0,25,button);
    drawText(paused?"▶":"Ⅱ",269,187,0.8f,rgb(255,255,255));
    drawText(paused?"PLAY":"PAUSE",246,218,0.38f,rgb(245,248,255));

    if(intro){
        C2D_DrawRectangle(12,68,1,296,156,rgb(8,16,40),rgb(8,16,40),rgb(8,16,40),rgb(8,16,40));
        drawText("WINTERSTAD",26,78,0.75f,rgb(255,214,92));
        drawText(introText[introStep],26,116,0.48f,rgb(245,248,255));
        drawText("A / TOUCH = verder",26,196,0.42f,rgb(180,205,235));
    }
    if(gameWon){
        C2D_DrawRectangle(25,70,270,156,100,rgb(24,110,66),rgb(24,110,66),rgb(24,110,66),rgb(24,110,66));
        drawText("WINTERSTAD GERED!",47,92,0.72f,rgb(255,255,255));
        drawText("A = opnieuw spelen",75,140,0.48f,rgb(255,255,255));
    }
}

static void advanceMission(void){
    mission++;
    missionStarted=0;
    missionBase=0;
    missionTimer=0;
    packageState=0;
    treeCount=0;
    ringCount=0;
    if(mission>=12){gameWon=1;mission=11;}
}

static void updateMission(float dt){
    if(intro||paused||gameWon) return;
    switch(mission){
        case 0: if(walked>=20) advanceMission(); break;
        case 1: if(jumpsDone>=3) advanceMission(); break;
        case 2: if(climbTime>=2.0f) advanceMission(); break;
        case 3: if(swingTime>=2.5f) advanceMission(); break;
        case 4: if(attackCount>=2) advanceMission(); break;
        case 5: if(mugsCollected>=10) advanceMission(); break;
        case 6: if(snowDefeated>=5) advanceMission(); break;
        case 7:
            if(packageState==0 && dist2(player.x,player.z,13,35)<5) packageState=1;
            else if(packageState==1 && dist2(player.x,player.z,70,35)<6) advanceMission();
            break;
        case 8:
            if(treeCount<5){
                int i=treeCount;
                if(dist2(player.x,player.z,trees[i].p.x,trees[i].p.z)<6){trees[i].active=0;treeCount++;}
            } else advanceMission();
            break;
        case 9:
            if(ringCount<8 && rings[ringCount].active && sqrtf(
                (player.x-rings[ringCount].p.x)*(player.x-rings[ringCount].p.x)+
                (player.y-rings[ringCount].p.y)*(player.y-rings[ringCount].p.y)+
                (player.z-rings[ringCount].p.z)*(player.z-rings[ringCount].p.z))<7){
                rings[ringCount].active=0;ringCount++;
            }
            if(ringCount>=8) advanceMission();
            break;
        case 10:
            if(player.y>105 && dist2(player.x,player.z,80,80)<10) advanceMission();
            break;
        case 11:
            if(bossHp<=0) advanceMission();
            break;
    }
}

static void doAttack(void){
    if(attackTimer>0||paused||intro) return;
    attackTimer=.28f;
    attackCount++;
    if(hero==1){
        float fx=sinf(yaw),fz=cosf(yaw);
        for(int i=0;i<MAX_SNOW;i++) if(snowmen[i].alive){
            float dx=snowmen[i].p.x-player.x,dz=snowmen[i].p.z-player.z;
            float d=sqrtf(dx*dx+dz*dz);
            if(d<5 && (dx*fx+dz*fz)>0){snowmen[i].alive=0;snowDefeated++;}
        }
        if(mission==11){
            float d=dist2(player.x,player.z,boss.x,boss.z);
            if(d<9 && player.y>103) bossHp--;
        }
    } else {
        specialTimer=.22f;
    }
}

static void doSpecial(void){
    if(specialTimer>0||paused||intro) return;
    if(hero==1){
        vel.x=sinf(yaw)*22; vel.z=cosf(yaw)*22; vel.y=7; specialTimer=.8f;
    } else {
        specialTimer=1.0f;
        swingTime+=.25f;
    }
}

static void jumpStart(void){
    if(player.y<=0.05f){vel.y=13;jumpsDone++;}
    else if(hero==0){vel.y=11;jumpsDone++;}
}

static void updatePlayer(float dt){
    if(paused||intro||gameWon) return;
    circlePosition cp;
    hidCircleRead(&cp);
    float fx=sinf(yaw),fz=cosf(yaw);
    float sx=cosf(yaw),sz=-sinf(yaw);
    float moveX=(float)cp.dx/156.0f, moveZ=(float)cp.dy/156.0f;
    float dx=fx*moveZ+sx*moveX, dz=fz*moveZ+sz*moveX;
    float len=sqrtf(dx*dx+dz*dz);
    if(len>1){dx/=len;dz/=len;}
    float speed=hero?6.0f:7.0f;
    vel.x += (dx*speed-vel.x)*dt*7.0f;
    vel.z += (dz*speed-vel.z)*dt*7.0f;
    if(len<.08f){vel.x*=0.86f;vel.z*=0.86f;}
    walked += sqrtf(vel.x*vel.x+vel.z*vel.z)*dt;

    if(charging){
        jumpCharge+=dt;
        if(jumpCharge>1.0f)jumpCharge=1.0f;
    }
    vel.y-=25.0f*dt;

    float nx,nz,top;
    int wall=nearBuilding(player.x,player.z,&nx,&nz,&top);
    if(wall && hero==0 && hidKeysHeld()&KEY_B){
        vel.y=10;
        climbTime+=dt;
    }
    if(specialTimer>0 && hero==0){
        float targetX=player.x+fx*20,targetZ=player.z+fz*20;
        for(int i=0;i<buildingCount;i++){
            float d=dist2(player.x,player.z,buildings[i].x,buildings[i].z);
            if(d<55 && d>5){targetX=buildings[i].x;targetZ=buildings[i].z;break;}
        }
        vel.x+=(targetX-player.x)*dt*1.5f;
        vel.z+=(targetZ-player.z)*dt*1.5f;
        swingTime+=dt;
    }

    player.x+=vel.x*dt;
    player.z+=vel.z*dt;
    player.y+=vel.y*dt;

    if(player.y<=0){player.y=0;vel.y=0;}
    if(wall && player.y<top-.2f){
        if(fabsf(player.x-buildings[0].x)>0){} /* keep compiler happy */
    }
    if(player.y>120)player.y=120;

    if(player.x<-120)player.x=-120;if(player.x>120)player.x=120;
    if(player.z<-120)player.z=-120;if(player.z>120)player.z=120;

    for(int i=0;i<MAX_MUGS;i++) if(mugs[i].active && dist2(player.x,player.z,mugs[i].p.x,mugs[i].p.z)<2){
        mugs[i].active=0;mugsCollected++;hp=hp<5?hp+1:5;
    }
    for(int i=0;i<MAX_SNOW;i++) if(snowmen[i].alive && dist2(player.x,player.z,snowmen[i].p.x,snowmen[i].p.z)<1.5 && player.y<3){
        if(attackTimer<=0){hp--;vel.x*= -1;vel.z*=-1;}
    }
    if(hp<=0){hp=5;player=v3(31,0,31.5f);vel=v3(0,0,0);mission=0;intro=1;introStep=0;}
    updateMission(dt);
}

static void updateCamera(float dt){
    u32 down=hidKeysDown();
    if(down&KEY_DLEFT) yaw-=.15f;
    if(down&KEY_DRIGHT) yaw+=.15f;
    if(down&KEY_DUP) pitch=clampf(.05f,.8f,pitch+.05f);
    if(down&KEY_DDOWN) pitch=clampf(.05f,.8f,pitch-.05f);
    if(down&KEY_X){hero^=1;}
    if(down&KEY_A && !intro) doAttack();
    if(down&KEY_R && !intro) doSpecial();
    if(down&KEY_B && !intro && player.y<.2f) charging=1;
    if(!(hidKeysHeld()&KEY_B) && charging){
        if(jumpCharge>.2f){vel.y=13+jumpCharge*19;jumpsDone++;}else jumpStart();
        charging=0;jumpCharge=0;
    }
    if(down&KEY_Y){
        float now=gameTime;
        if(now-lastYTap<.35f){
            musicTrack=(musicTrack+2)%3;
        }else{
            musicTrack=(musicTrack+1)%3;
        }
        lastYTap=now;
        musicLoad(musicTrack);
    }
}

static void drawTop3D(void){
    C3D_FrameDrawOn(topTarget);
    C3D_RenderTargetClear(topTarget,C3D_CLEAR_ALL,CLEAR_COLOR,0);
    Mtx_PerspTilt(&projection,C3D_AngleFromDegrees(62),C3D_AspectRatioTop,.1f,400.0f,true);
    C3D_Mtx view;
    V3 eye=v3(player.x+sinf(yaw)*9,player.y+3.0f+sinf(pitch)*4,player.z+cosf(yaw)*9);
    V3 target=v3(player.x,player.y+1.5f,player.z);
    Mtx_LookAt(&view,FVec3_New(eye.x,eye.y,eye.z),FVec3_New(target.x,target.y,target.z),FVec3_New(0,1,0),true);
    drawWorld(&view);
    drawPlayer(&view);
}

int main(void){
    gfxInitDefault();
    romfsInit();
    ndspInit();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();
    topTarget=C2D_CreateScreenTarget(GFX_TOP,GFX_LEFT);
    bottomTarget=C2D_CreateScreenTarget(GFX_BOTTOM,GFX_LEFT);
    font=C2D_FontLoadSystem(CFG_REGION_USA);
    textBuf=C2D_TextBufNew(8192);
    initShader();
    buildCity();
    musicLoad(0);

    while(aptMainLoop()){
        hidScanInput();
        gameTime+=1.0f/60.0f;
        if(music.loaded && !paused){
            music.elapsed+=1.0f/60.0f;
            if(music.elapsed>=musicLengths[musicTrack]) musicNext();
        }
        u32 down=hidKeysDown();

        touchPosition touch;
        hidTouchRead(&touch);
        if(down&KEY_START) break;

        if(touch.px>=250 && touch.px<=315 && touch.py>=175 && touch.py<=235){
            if(!intro) paused=!paused;
        }
        if(intro && (down&KEY_A || down&KEY_TOUCH)){
            introStep++;
            if(introStep>=11){intro=0;mission=0;}
        }

        updateCamera(1.0f/60.0f);
        updatePlayer(1.0f/60.0f);
        if(attackTimer>0) attackTimer-=1.0f/60.0f;
        if(specialTimer>0) specialTimer-=1.0f/60.0f;

        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        drawTop3D();
        drawBottom();
        C3D_FrameEnd(0);
    }

    C2D_TextBufDelete(textBuf);
    C2D_FontFree(font);
    C2D_Fini();
    shaderProgramFree(&program);
    DVLB_Free(vshader_dvlb);
    musicStop();
    ndspExit();
    romfsExit();
    C3D_Fini();
    gfxExit();
    return 0;
}
