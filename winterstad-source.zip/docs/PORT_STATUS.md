# Winterstad native 3DS port — v0.4

Source used: `source/Winterstad_3D_original.html`.

The source is a Three.js/WebGL browser game. Its native port is implemented in
`native/source/main.c` with libctru, Citro3D and Citro2D.

## Source elements ported into native code

- R6-style Spidey and Deadpool proportions
- winter-city building grid
- snowmen enemies
- chocolate-milk pickups
- player HP
- movement / jumping / superjump
- wall climbing
- Spidey web/swing special
- Deadpool dash
- attack behaviour
- package delivery
- Christmas-tree objective
- 8-ring race
- highest-tower climb
- Frostbite boss
- 12 mission structure
- intro dialogue structure
- minimap concept
- bottom HUD
- touch pause/play
- no FPS counter

## Extracted source assets

All 27 embedded `SRC` images from the HTML were extracted into
`romfs/assets/`. The original HTML is also preserved verbatim in `source/`.

## Deliberate 3DS adaptations

The browser renderer used Three.js/WebGL and dynamically generated browser
textures. Native 3DS rendering therefore uses Citro3D low-poly geometry and
the extracted image assets are kept in RomFS for native texture integration.
The renderer is designed around the original 3DS hardware rather than trying
to execute JavaScript/WebGL on the console.

The source game's browser music implementation is WebAudio-generated in this
HTML file. No external MP3 files were embedded in the supplied HTML, so this
native package does not invent replacement songs. When the three original
master MP3s are added to the project, they can be converted to PCM/WAV for
NDSP playback without changing the source masters.

## Music update
- The three supplied songs are now bundled in RomFS as 11.025 kHz mono PCM16 WAV files.
- Native NDSP playback is wired to the game.
- Track 1 starts automatically.
- Y advances to the next song; double-tap Y goes to the previous song.
- Songs automatically advance when the current track reaches its known duration.
- Only the currently playing track is loaded into linear memory, rather than all three at once.
