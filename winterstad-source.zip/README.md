# Winterstad — native Nintendo 3DS port

This repository is a native C/libctru/Citro3D port built from the supplied
`Winterstad 3D_fixed(3).html`.

## What is actually ported here

- Native 3D top-screen renderer (Citro3D/PICA200)
- Winter city made from low-poly native geometry
- Spidey + Deadpool R6/Roblox-like proportions and colour schemes from the source
- Walking / Circle Pad movement
- D-pad camera
- B jump; hold B for super jump
- Spidey wall climb
- Spidey web/swing special
- Deadpool dash special
- A attack
- Visible web attack / Deadpool sword attack
- HP / damage
- Snowmen enemies
- Chocolate-milk pickups
- 12 mission progression matching the source mission structure
- Package delivery, Christmas trees, ring race, tower climb and Frostbite boss logic
- Touchscreen pause/play control
- Bottom-screen minimap + hearts + objective UI
- No FPS counter
- Original embedded image assets extracted to `romfs/assets/`
- Original HTML retained in `source/` as the gameplay/asset reference

## Build

On GitHub Actions the `devkitpro/devkitarm` container is used by the workflow.
The workflow runs `make` and uploads `output/winterstad.3dsx`.

Local build, if devkitPro 3DS development tools are installed:

    make

The source is intentionally kept low-poly so it can target original 3DS hardware.

## Important

The supplied HTML used Three.js/WebGL and browser APIs, so it cannot be copied
into a `.3dsx` unchanged. The native source in `native/source/main.c` is the
actual 3DS runtime implementation; the original HTML is preserved as the
authoritative reference for assets, missions and behaviour.
